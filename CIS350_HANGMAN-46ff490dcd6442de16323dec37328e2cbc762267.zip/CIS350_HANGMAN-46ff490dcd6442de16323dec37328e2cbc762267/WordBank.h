#ifndef WORDBANK_H_INCLUDED
#define WORDBANK_H_INCLUDED

extern char *bank[] = {
        "WINS","LOSE","BANK","BIKE", "KITE",
        "FIGHT","MIGHT","BEACH","ADULT","STACK",
        "STRING","FLIGHT","ENTITY","EMPIRE","FOLLOW",
        "ALCOHOL","COLLEGE","CAPTURE","FICTION","DESPITE",
        "ONGOING","OUTSIDE","PACKAGE","OVERALL","NOTHING"

    };

#endif // WORDBANK_H_INCLUDED
